Author Becky Workman
Section: Core Java/Hibernate/JUnit
Instructor: Ms. Lewis
Date: 1/16/23
Description: SBA creating a program allowing students to see all their courses and register for new ones.

Program Running directions:
Change username and password in association to your localhost.
Database will create if it doesn't exist 
Insert student table and course table rows from Student(dash)1.sql and Course(dash)1.sql